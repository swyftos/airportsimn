# Person 2 private-only demand and operations — PLACEHOLDER

This is a reproducible **fictional FBO** demo for February 11–17, 2027. Every aircraft count, hourly pattern, service time, parking price, physical stand count, weather effect and security-disruption duration in this package is **synthetic or an unverified team assumption**. It is **not an observed private-fleet forecast or measured FBO accuracy**. The modeled scope is selected private aircraft only; charter, air taxi, airlines and military traffic are excluded. No FAA GA or airport-wide count is treated as a customer count.

Open [results/report.html](results/report.html) for the readable report. Run `python run_demo.py` to regenerate the matched forecast, operational outputs and SHA-256 manifest. Run `python -m unittest test_forecast_model test_operations_extension -v` to validate behavior. Python 3.10+ and the standard library suffice. The default random seed is 42; `python run_demo.py --seed 123` changes it reproducibly. All files in `results/` are regenerated as one release.

## What the placeholder model answers

- **How many arrive and leave:** `results/daily_totals.csv` gives expected arrivals and departures for Low, Medium and High demand on each planning day. `results/capacity_plan.csv` gives accepted landings/departures, unserved requests and aircraft remaining on the ground. Expected values are fractional model means; accepted counts are whole-aircraft planning decisions.
- **When it is busy:** `results/hourly_activity_curve.csv` has 504 date/scenario/hour rows in Los Angeles local time. The fitted weekday/weekend hour shares are in `results/hourly_profile_weights.csv`. The top hours in the Medium demo are February 15 around 07:00–10:59, driven by an invented departure peak. Within-day Low/Medium/High *activity bands* rank hours separately from the Low/Medium/High *demand scenarios*.
- **How long an aircraft takes:** `results/turnaround_time_estimates.csv` has separate fictional landing-runway, taxi-in, unload, fuel, reload, taxi-out and takeoff-runway stages. Mix-weighted means are about 3.9, 8.8, 17.6, 34.3, 15.8, 10.8 and 2.9 minutes, respectively. The base landing-to-park time is about 12.7 minutes; park-to-takeoff is about 13.7 minutes; minimum sequential service turnaround is about 94 minutes. These are **not** flight time, an ATC slot, an airport operating limit, or overnight parking dwell.
- **Parking and price:** the capacity illustration uses **24 invented physical stands** plus the team's **unverified 75 space units**. Both are ceilings; the stricter applies. `results/parking_price_scenarios.csv` gives invented per-aircraft, per-24-hour rates: light $250/$312.50/$375; midsize $400/$500/$600; large $700/$875/$1,050 for Low/Medium/High traffic. No real FBO tariff or available stand count has been established.
- **Weather:** `results/weather_sensitivity.csv` adds hypothetical rain/low-visibility minutes and illustrates 1.0/0.85/0.65 airport-throughput factors. Demand is unchanged in this sensitivity. No actual weather forecast or slot allocation is supplied.
- **Presidential presence:** **no visit is assumed**. `results/presidential_security_sensitivity.csv` asks what a hypothetical 0-, 2- or 4-hour complete movement pause on February 14 would do to the hourly private-only forecast. The model **does not say an airport closure is required or predict its duration**. The FAA notice and airport/security coordination determine any actual restriction. This is separate from the unmeasured Presidents Day demand sensitivity.

The hourly curve is
`expected arrivals at hour h = daily expected arrivals × fitted arrival share(day type,h)`;
departures use the same formula with their own fitted departure shares. Shares sum to one over 24 hours. The model fits those shares to **seeded synthetic 2023–2025 hourly samples**, kept in `results/demo_hourly_history.csv`. It fits daily category arrivals/departures on synthetic 2023–2025 FBO history, after excluding 2020–2022. The 2023–2025 chronological holdout tests program behavior only.

## Provenance and assumptions

The team's 20% FBO capture applies once to a **synthetic eligible private-aircraft pool**, never all LAX tower operations. The team 47% light / 33% midsize / 20% large mix is used across categories. Synthetic event multipliers for each day and demand tier are explicit in `results/demo_planning_inputs.csv`; simulated reservations act as a floor and are not added twice. The separate February 15 Presidents Day ±10% cases are hypothetical and do not alter the primary forecast. The base demand forecast, uncertainty outputs, evaluation metrics and metadata retain their existing filenames and columns for Nazar's dashboard.

`results/placeholder_assumptions.csv`, `results/operations_run_metadata.json`, `results/private_fleet_run_metadata.json` and `results/placeholder_manifest.json` document assumptions, run state and matching file hashes. The older selected-Part-135 split has been removed from this package. Alan should replace the eligibility/capture assumption, actual stands and footprint limits, operating times, prices, weather/ATC impacts, real booking records and any FAA notice before operational use.

The existing forecast engine accepts replacement daily FBO history and planning inputs through `python forecast_model.py --history PATH --planning PATH --output-dir PATH`. See its existing CSV headers for the input contract. The added hourly/service layer currently generates transparent synthetic samples; `operations_extension.py` contains the isolated profile, duration, weather, price and VIP functions to replace when matching real records arrive. Retrain and regenerate all outputs from a single input set; do not mix runs. No current source verifies private-only demand, a price, an FBO parking capacity, a presidential visit, or a closure length.

## External references

These links establish definitions and qualitative mechanisms, **not** the placeholder values:

- [FAA weather-delay explanation](https://www.faa.gov/nextgen/programs/weather/faq) — weather can reduce usable capacity and lead to delays.
- [FAA temporary flight restriction guidance](https://www.faa.gov/uas/getting_started/where_can_i_fly/airspace_restrictions/tfr) — actual VIP restriction times and permitted operations are specified in the applicable notice.
- [FAA airport capacity profiles](https://www.faa.gov/airports/planning_capacity/profiles) — airport-wide capacity context, not fictional FBO stands or available 2027 slots.
- [Team assumptions ledger](https://github.com/swyftos/airportsimn/blob/main/assumptions.csv) — 20% capture and 47/33/20 mix, subject to private-only scope review.
- [Elia parking assumptions](https://github.com/swyftos/airportsimn/blob/main/elia/assumptions_p3.csv) — inherited 75-space-unit estimate, not confirmed free capacity.

`results/operational_source_links.csv` repeats the URLs with their limitations.
