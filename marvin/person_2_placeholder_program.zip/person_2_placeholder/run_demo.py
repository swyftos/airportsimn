"""Run the explicitly labeled placeholder Person 2 demo."""
import argparse,csv,json,subprocess,sys,html,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
def read(path):
    with path.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def table(rows,columns):
    return '<table><thead><tr>'+''.join('<th>'+html.escape(k.replace('_',' '))+'</th>' for k in columns)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r[k]))+'</td>' for k in columns)+'</tr>' for r in rows)+'</tbody></table>'
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--seed',type=int,default=42);args=parser.parse_args()
    out=HERE/'results';out.mkdir(exist_ok=True)
    subprocess.run([sys.executable,str(HERE/'forecast_model.py'),'--demo','--seed',str(args.seed),'--output-dir',str(out)],check=True)
    history=read(out/'demo_historical_traffic.csv')
    reference=[r for r in history if r['date'].startswith('2022-02')]
    with (out/'placeholder_feb2022_reference.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(reference[0]));w.writeheader();w.writerows(reference)
    totals=read(out/'daily_totals.csv');metrics=read(out/'evaluation_metrics.csv')
    assumptions={'status':'PLACEHOLDER','seed':args.seed,'source':'Random synthetic generator; no FAA or LAX observations used',
                 'history_coverage':'2016-01-01 through 2025-12-31','covid_years_excluded_from_fitting':[2020,2021,2022],
                 'fit_window':'2023-2025 only; pre-2023 records retained as reference',
                 'fbo_baseline':'Invented category means 7 light, 5 midsize, 3 large movements per direction/day before season and weekday effects',
                 'seasonality':'Invented 15% cosine seasonal amplitude, peak near February',
                 'weekday':'Invented 1.2 factor Mon/Fri/Sun, 0.85 otherwise',
                 'random_counts':'Rounded nonnegative Gaussian draws with standard deviation sqrt(category mean)',
                 'reservations':'Random synthetic booked arrival/departure counts; random assumed show rate 75-95%; no occupancy or booking records',
                 'event_profiles':'Random arrival/departure uplift profiles; Low=half Medium incremental uplift; High=1.6x Medium incremental uplift',
                 'event_reference':'February 2022 file is random placeholder history, not an investigation of observed LVI activity',
                 'uncertainty':'Nominal 90% split-conformal baseline ranges; assumed event scaling; no validated event coverage',
                 'evaluation':'Synthetic holdout vs synthetic training mean; no observed-outcome accuracy claim',
                 'operating_baseline':'Fictional demonstration, not realistic/validated FBO traffic or capacity'}
    (out/'placeholder_assumptions.json').write_text(json.dumps(assumptions,indent=2),encoding='utf-8')
    contract=json.loads((HERE/'forecast_output_contract.json').read_text(encoding='utf-8-sig'))
    for name,cols in contract['csv_columns'].items():
        assert list(read(out/name)[0])==cols
    assert list(json.loads((out/'run_metadata.json').read_text()))==contract['metadata_keys']
    meta=json.loads((out/'run_metadata.json').read_text())
    content='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PLACEHOLDER — Person 2 Forecast</title><style>
body{font:16px system-ui,sans-serif;margin:0;background:#f3f5f9;color:#17243b}main{max-width:1120px;margin:32px auto;padding:24px}h1{font-size:32px}h2{margin-top:32px}.warning{background:#fff0c2;border-left:6px solid #b67900;padding:18px;border-radius:6px}.card{background:white;border:1px solid #dce2ec;padding:20px;border-radius:12px;margin:20px 0;overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:10px;text-align:left;border-bottom:1px solid #dce2ec}th{background:#edf2f9}tbody tr:nth-child(even){background:#f7f9fc}code{background:#edf2f9;padding:2px 5px}a{color:#145ca6}
</style><main><div class="warning"><strong>PLACEHOLDER — SYNTHETIC DEMONSTRATION ONLY</strong><br>All traffic, reservations, event uplifts and forecasts below are invented. Not FAA observations, real bookings, validated FBO demand or operational advice.</div><h1>Person 2 — AI demand forecasting</h1><p>February 11–17, 2027 · Fictional FBO · Three aircraft categories · Low / Medium / High scenarios</p>'''
    content+=f'<p>Random seed: <strong>{args.seed}</strong>. Repeat with the same seed for identical CSV values.</p>'
    content+='<section class="card"><h2>Seven-day demand — PLACEHOLDER</h2><p>Baseline is ordinary synthetic traffic. Expected includes assumed event uplift and a reservation floor; incremental is expected minus baseline. Fractional values are expectations, not actual aircraft bookings.</p>'
    content+=table(totals,list(totals[0]))+'</section>'
    content+='<section class="card"><h2>Synthetic backtest — not observed accuracy</h2><p>Chronological 60% train / 20% calibration / 20% test within 2023–2025. The model is frozen after training. Scores show behavior on this random generator only.</p>'
    content+=table(metrics,['aircraft_category','target','model_mae','historical_mean_mae','improvement_percent','test_coverage'])+'</section>'
    content+='<section class="card"><h2>Uncertainty and assumptions</h2><p>Nominal 90% baseline prediction ranges are scaled by assumed event multipliers. These are not validated event confidence intervals. Do not add category bounds to claim a calibrated total range.</p><p><a href="uncertainty_results.csv">Category prediction ranges (CSV)</a> · <a href="demand_predictions.csv">Detailed forecasts (CSV)</a> · <a href="placeholder_assumptions.json">Placeholder assumptions</a> · <a href="run_metadata.json">Run metadata</a></p></section></main></html>'
    (out/'report.html').write_text(content,encoding='utf-8')
    files=[f for f in out.iterdir() if f.is_file() and f.name!='placeholder_manifest.json']
    manifest={'status':'PLACEHOLDER','seed':args.seed,'files':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
    (out/'placeholder_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('PLACEHOLDER demo complete. Open results/report.html. No observed accuracy claims.')
if __name__=='__main__':main()

